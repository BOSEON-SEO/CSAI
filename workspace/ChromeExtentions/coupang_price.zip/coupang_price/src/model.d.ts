interface MessageResponse<T = any> {
  error?: string;
  data?: T;
}

interface BackgroundStatus {
  currentIndex: number;
  taskList: ProductInitInfo[];
  resultList: ProductResultInfo[];
  refetchedAt: number;
  batchSize: number;
}

interface ProductInitInfo {
  no: number;
  skuId: string;
  productId: string;
  vendorItemId: string;
  productName: string;
}

// MODIFIED: 'sent' 상태 추가
interface ProductResultInfo {
  skuId: string;
  price: {
    original: number;
    sales: number;
    final: number;
  };
  status: 'pending' | 'processing' | 'failed' | 'out-of-stock--temporary' | 'out-of-stock--permanent' | 'completed' | 'sent';
  productName: string;
  error?: string;
}

interface RetryInfo {
  currentIndex: number;
  totalCount: number;
  skuId: string;
  retryCount: number;
  maxRetries: number;
  retryInterval: number;
}

interface CrawlBatchCompleteInfo {
  currentIndex: number;
  pageSize: number;
  totalCount: number;
}

interface CrawlMessage {
  type: 'CRAWL_START' | 'CRAWL_STOP' | 'CRAWL_SUCCESS' | 'CRAWL_PROGRESS' | 'CRAWL_COMPLETE' | 'CRAWL_ERROR' | 'CRAWL_RETRY' | 'CRAWL_BATCH_COMPLETE' | 'CRAWL_FAILED' | 'RETRY_STOP';
  data?: ProductResultInfo | ProductInitInfo | RetryInfo | CrawlBatchCompleteInfo;
  error?: string;
  payload?: any;
}

interface CrawlConfig {
  batchSize: number;
  interval: {
    min: number;
    max: number;
  };
  retry: {
    max: number;
    interval: number;
  };
}
