document.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.sendMessage({ type: 'GET_CONFIG' }, (response: MessageResponse<CrawlConfig>) => {
    if (response.error) {
      alert(`저장된 설정을 불러오지 못했습니다: ${response.error}`);
    } else {
      const { batchSize, interval: { min, max }, retry: { max: retryMax, interval: retryInterval } } = response.data!;

      (document.getElementById('batchSize') as HTMLInputElement)!.value = batchSize.toString();
      (document.getElementById('intervalMin') as HTMLInputElement)!.value = (min / 1000).toString();
      (document.getElementById('intervalMax') as HTMLInputElement)!.value = (max / 1000).toString();
      (document.getElementById('retryMax') as HTMLInputElement)!.value = retryMax.toString();
      (document.getElementById('retryInterval') as HTMLInputElement)!.value = (retryInterval / 1000).toString();
    }
  });

  document.getElementById("configForm")!.addEventListener("submit", (e) => {
    e.preventDefault();

    const formData = new FormData(e.target as HTMLFormElement);
    const config = Object.fromEntries(formData);

    const { batchSize, intervalMin, intervalMax, retryMax, retryInterval } = config;

    chrome.runtime.sendMessage({ type: 'UPDATE_CONFIG', payload: {
      batchSize: parseInt(batchSize as string),
      interval: {
        min: parseInt(intervalMin as string) * 1000,
        max: parseInt(intervalMax as string) * 1000
      },
      retry: {
        max: parseInt(retryMax as string),
        interval: parseInt(retryInterval as string) * 1000
      }
    }}, (response: MessageResponse<CrawlConfig>) => {
      if (response.error) {
        alert(`설정을 저장하지 못했습니다: ${response.error}`);
      } else {
        alert("설정이 저장되었습니다.");
      }
    });
  });
});
